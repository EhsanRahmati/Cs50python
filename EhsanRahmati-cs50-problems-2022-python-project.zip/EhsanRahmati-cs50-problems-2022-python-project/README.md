# Age calcution and leap year declaration
    #### Video Demo:  <https://aparat.com/v/d0ipY>
    #### Description:
    Greetings and blessings to all the teachers of the CS50 course and all those who worked hard to hold this course.
    I am Ehsan Rahmati, a student of electrical engineering at Boyin Zahra Higher Education Center, Qazvin Province, Iran.
    I live in the city of Arak, located in the Central Province of Iran.
    I started programming about 6 months ago and I have a fundamental: programming foundation degree from LinkedIn.
    I also have a Linux introductory programming degree.
    My project is grade and age in Python and it is written by one main function and three sub-functions.
    and I have used two libraries.
    In the first function, we control the input of the program, so that if the number of input words is less than 3, it will display few in the output, and if it is more than 3, it will display many, if csv is not in the input, it will display not csv file and exit the program.
    In the second function, we discuss the houses in the initial csv file, which is determined according to the input character of their group.
    In the third function, the basis of each member inside the csv is discussed. In the main function, we design the output. And we open the new file using the sys and csv library.
    We define an empty data dictionary, then we read the new-students.csv file with the help of the try loop, but if the file is not found, the system exits the program with the statement "couldn't find csv file".
    then we create a dictionary called output[] and with a for loop we change the characteristic value to house and the year of birth to grade using the grade function.
    Then we run the after csv file using the csv library and also sys and that's it. We put the above information in the output and rebuild the name, house and grade columns
    I hope you enjoy. Yours faithfully, Ehsan Rahmati
